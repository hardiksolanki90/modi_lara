<?php
namespace App\Objects;

use App\Objects\IDB;

class Block extends IDB
{
    protected $table = 'block';
}
