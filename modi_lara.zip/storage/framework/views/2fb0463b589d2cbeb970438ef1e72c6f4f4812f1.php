<?php if($data['type'] == 'select'): ?>
<div class="form-group myForm-group is-focused">
  <?php if($data['label']): ?>
    <label for="<?php echo e($data['id']); ?>"><?php echo e($data['label']); ?></label>
  <?php endif; ?>
  <select class="<?php echo e($data['class']); ?> form-control  <?php if($data['multiple']): ?> multi <?php endif; ?>" name="<?php echo e($data['name']); ?>" id="<?php echo e($data['id']); ?>" <?php echo e(($data['multiple'] ? 'multiple' : '')); ?>>
    <?php if($data['show_label_as_option'] && $data['label']): ?>
      <option value=""><?php echo e($data['label']); ?></option>
    <?php endif; ?>
    <?php $__currentLoopData = $data['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($data['value_key'] && $data['text_key']): ?>
        <?php if($data['multiple']): ?>
          <option value="<?php echo e($option[$data['value_key']]); ?>" <?php echo e((in_array($option[$data['value_key']], $data['value']) ? 'selected' : '')); ?>><?php echo e($option[$data['text_key']]); ?></option>
        <?php else: ?>
          <option value="<?php echo e($option[$data['value_key']]); ?>" <?php echo e(($option[$data['value_key']] == $data['value'] ? 'selected' : '')); ?>><?php echo e($option[$data['text_key']]); ?></option>
        <?php endif; ?>
      <?php elseif($data['text_as_value']): ?>
        <option value="<?php echo e($option); ?>" <?php echo e(($option == $data['value'] ? 'selected' : '')); ?>><?php echo e($option); ?></option>
      <?php else: ?>
        <option value="<?php echo e($value); ?>" <?php echo e(($value == $data['value'] ? 'selected' : '')); ?>><?php echo e($option); ?></option>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
</div>
<?php endif; ?>


<?php if($data['type'] == 'radio'): ?>
<?php if($data['label']): ?>
<label class="_radio_label" for=""><?php echo e($data['label']); ?></label>
<?php endif; ?>
<div class="custom-control custom-radio-wrap <?php echo e(($data['wrapper_class'] == 'css_switch') ? 'switch_css switch--horizontal' : ''); ?> <?php echo e($data['wrapper_class']); ?>">
  <?php if($data['wrapper_class'] != 'css_switch'): ?>
    <?php $__currentLoopData = $data['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($data['wrapper_class'] != 'switch'): ?>
      <div class="custom-control custom-radio <?php echo e(($data['inline'] ? 'custom-control-inline' : '')); ?>">
      <?php endif; ?>
        <?php if($data['value_key'] && $data['text_key']): ?>
          <input <?php echo e(($data['value'] == $option[$data['value_key']] ? 'checked' : '')); ?> type="radio" id="<?php echo e($data['name']); ?>_<?php echo e($option[$data['value_key']]); ?>" name="<?php echo e($data['name']); ?>" class="custom-control-input" value="<?php echo e($option[$data['value_key']]); ?>">
          <label class="custom-control-label" for="<?php echo e($data['name']); ?>_<?php echo e($option[$data['value_key']]); ?>"><?php echo e($option[$data['text_key']]); ?></label>
        <?php elseif($data['text_as_value']): ?>
          <input <?php echo e(($data['value'] == $option ? 'checked' : '')); ?> type="radio" id="<?php echo e($data['name']); ?>_<?php echo e($option); ?>" name="<?php echo e($data['name']); ?>" class="custom-control-input" value="<?php echo e($option); ?>">
          <label class="custom-control-label" for="<?php echo e($data['name']); ?>_<?php echo e($option); ?>"><?php echo e($option); ?></label>
        <?php else: ?>
          <input <?php echo e(($data['value'] == $value ? 'checked' : '')); ?> type="radio" id="<?php echo e($data['name']); ?>_<?php echo e($value); ?>" name="<?php echo e($data['name']); ?>" class="custom-control-input" value="<?php echo e($value); ?>">
          <label class="custom-control-label" for="<?php echo e($data['name']); ?>_<?php echo e($value); ?>"><?php echo e($option); ?></label>
        <?php endif; ?>
      <?php if($data['wrapper_class'] != 'switch'): ?>
      </div>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <a class="radio_slider"></a>
  <?php else: ?>
    <div class="switch_css switch--horizontal">
      <?php $__currentLoopData = $data['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <input <?php echo e(($data['value'] == $value ? 'checked' : '')); ?> type="radio" id="<?php echo e($data['name']); ?>_<?php echo e($value); ?>" name="<?php echo e($data['name']); ?>" class="<?php echo e($data['name']); ?>_<?php echo e($value); ?>" value="<?php echo e($value); ?>">
        <label for="<?php echo e($data['name']); ?>_<?php echo e($value); ?>"><?php echo e($option); ?></label>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <span class="toggle-outside">
        <span class="toggle-inside"></span>
      </span>
    </div>
  <?php endif; ?>
</div>
<?php endif; ?>

<?php if($data['type'] == 'checkbox'): ?>
<div class="custom-control custom-checkbox">
  <?php if($data['label']): ?>
    <label class="_checkbox_label" for=""><?php echo e($data['label']); ?></label>
  <?php endif; ?>
  <?php $__currentLoopData = $data['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($data['value_key'] && $data['text_key']): ?>
      <?php if($data['multiple']): ?>
        <div class="custom-control custom-checkbox">
          <label>
            <input <?php echo e((in_array($option[$data['value_key']], $data['value']) ? 'checked' : '')); ?> type="checkbox" id="<?php echo e($data['name']); ?>_<?php echo e($option[$data['value_key']]); ?>" name="<?php echo e($data['name']); ?>" class="custom-control-input <?php echo e($data['class']); ?>" value="<?php echo e($option[$data['value_key']]); ?>">
              <?php echo e($option[$data['text_key']]); ?>

              <span class="custom-control-label"></span>
            </label>
        </div>
      <?php else: ?>
        <div class="custom-control custom-checkbox">
          <input <?php echo e(($data['value'] == $option[$data['value_key']] ? 'checked' : '')); ?> type="checkbox" id="<?php echo e($data['name']); ?>_<?php echo e($option[$data['value_key']]); ?>" name="<?php echo e($data['name']); ?>" class="custom-control-input <?php echo e($data['class']); ?>" value="<?php echo e($option[$data['value_key']]); ?>">
          <label class="custom-control-label" for="<?php echo e($data['name']); ?>_<?php echo e($option[$data['value_key']]); ?>"><?php echo e($option[$data['text_key']]); ?></label>
        </div>
      <?php endif; ?>
    <?php elseif($data['text_as_value']): ?>
      <div class="custom-control custom-checkbox <?php echo e(($data['inline'] ? 'custom-control-inline' : '')); ?>">
        <input type="checkbox" id="<?php echo e($data['name']); ?>_<?php echo e($option); ?>" name="<?php echo e($data['name']); ?>" class="custom-control-input" value="<?php echo e($option); ?>">
        <label class="custom-control-label" for="<?php echo e($data['name']); ?>_<?php echo e($option); ?>"><?php echo e($option); ?></label>
      </div>
    <?php else: ?>
      <div class="custom-control custom-checkbox <?php echo e(($data['inline'] ? 'custom-control-inline' : '')); ?>">
        <input type="checkbox" id="<?php echo e($data['name']); ?>_<?php echo e($value); ?>" name="<?php echo e($data['name']); ?>" class="custom-control-input" value="<?php echo e($value); ?>">
        <label class="custom-control-label" for="<?php echo e($data['name']); ?>_<?php echo e($value); ?>"><?php echo e($option); ?></label>
      </div>
    <?php endif; ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\modilara\resources\views\admin\hardik-admin\templates/form/select.blade.php ENDPATH**/ ?>