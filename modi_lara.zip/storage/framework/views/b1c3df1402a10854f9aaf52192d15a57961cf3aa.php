use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class <?php echo e(makeObject($comp_obj->table)); ?>Table extends Migration
{
    /**
     * Run the migrations.
     *
     * @return  void
     */
    public function up()
    {
        Schema::create('<?php echo e($comp_obj->table); ?>', function (Blueprint $table) {
          $table->increments('id');
      <?php $__currentLoopData = $comp_obj->fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($column->default): ?>
          <?php $default = "$column->default" ?>
        <?php else: ?>
          <?php $default = null ?>
        <?php endif; ?>
        <?php if($column->column_type == 'integer' || ($column->column_type == 'relationship' && $column->relationship_type != 'belongsToMany')): ?>
          $table->integer('<?php echo e($column->field_name); ?>')->unsigned()->default(<?php echo e($default); ?>)<?php echo (!$default ? '->nullable()' : ''); ?>;
        <?php elseif($column->column_type != 'relationship'): ?>
          $table-><?php echo e($column->column_type); ?>('<?php echo e($column->field_name); ?>')->default(<?php echo e($default); ?>)<?php echo (!$default ? '->nullable()' : ''); ?>;
        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          $table->timestamps();
          $table->softDeletes();
          $table->engine = 'InnoDB';
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return  void
     */
    public function down()
    {
        Schema::dropIfExists('<?php echo e($comp_obj->table); ?>');
    }
}
<?php /**PATH C:\wamp64\www\modilara\storage\components\templates/migration.blade.php ENDPATH**/ ?>