<?php $__env->startSection('content'); ?>
<div class="con">
  <div class="card">
    <div class="card-body">
      <?php echo $form->start('block-create-form', 'myForm'); ?>


        <?php echo $form->text([
          'name' => 'name',
          'required' => true,
          'label' => t('Name'),
          'value' => model($obj, 'name'),
          'class' => ''
          ]); ?>


        <?php echo $form->text([
          'name' => 'identifier',
          'required' => true,
          'label' => t('Identifier'),
          'value' => model($obj, 'identifier'),
          'class' => ''
        ]); ?>


        <?php echo $form->text([
          'name' => 'content',
          'required' => true,
          'label' => t('Content'),
          'value' => model($obj, 'content'),
          'class' => 'html-editor',
          'wrapper_class' => 'html-editor-wrap',
          'textarea' => true
        ]); ?>



        <?php echo $form->media([
          'name' => 'id_cover',
          'required' => true,
          'label' => t('Image'),
          'media' => model($obj, 'id_cover'),
          'multiple' => false
          ]); ?>



        <?php echo $form->media([
          'name' => 'id_pdf',
          'required' => true,
          'label' => t('PDF'),
          'media' => model($obj, 'id_pdf'),
          'object_type' => 'application',
          'multiple' => false
          ]); ?>


        <?php echo $form->choice([
          'name' => 'status',
          'required' => true,
          'label' => t('Status'),
          'value' => model($obj, 'status'),
          'wrapper_class' => 'switch',
          'type' => 'radio',
          'options' => ['Disabled', 'Enabled'],
          'reverse' => true
          ]); ?>

          <hr>
          <button type="submit" class="btn btn-primary btn-submit has-icon-right" name="button">
            <i class="ion-ios-download-outline"></i>
              <?php echo e(t('Save')); ?> block
          </button>
          <?php echo $form->end(); ?>

      </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\modilara\resources\views\admin\hardik-admin\templates/block/create.blade.php ENDPATH**/ ?>