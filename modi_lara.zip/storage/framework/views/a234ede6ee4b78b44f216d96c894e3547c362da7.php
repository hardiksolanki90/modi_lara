<?php $__env->startSection('content'); ?>
<div class="con">  
  <div class="_tw card">
    <div class="_tw_w card-body">
      <table class="table table-striped _ft" id="table_block">
        <thead>
          <tr>
            <th filter="id">ID</th>
            <th filter="name">name</th>
            <th filter="status">status</th>
            <th filter="identifier">identifier</th>
            <th><?php echo e(t('Actions')); ?></th>
          </tr>
          <tr class="filter"></tr>
        </thead>
        <tbody class="m-datatable__body">
          <?php echo $__env->make('block/_partials/list-only-block', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </tbody>
      </table>
      <div class="links" table="table_block">
        <?php echo e($obj->links()); ?>

      </div>
    
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\modilara\resources\views\admin\hardik-admin\templates/block/list.blade.php ENDPATH**/ ?>