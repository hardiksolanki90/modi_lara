
namespace App\Objects;

use App\Objects\IDB;
use Illuminate\Database\Eloquent\SoftDeletes;

class <?php echo e($object); ?> extends IDB
{
    use SoftDeletes;

    protected $table = '<?php echo e($table); ?>';
<?php if(count($fields)): ?>
<?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($field->relationship_type == 'belongsTo'): ?>

    public function <?php echo e(str_replace('id_', '', $field->field_name)); ?>()
    {
        return $this->belongsTo('App\Objects\<?php echo e(makeObject($field->component->variable)); ?>', '<?php echo e($field->local_key); ?>');
    }
<?php endif; ?>
<?php if($field->relationship_type == 'hasOne'): ?>

    public function <?php echo e($comp = $field->component->variable); ?>()
    {
        return $this->hasOne('App\Objects\<?php echo e(makeObject($comp)); ?>', '<?php echo e($field->foreign_key); ?>', '<?php echo e(($field->local_key ? $field->local_key : 'id')); ?>');
    }
<?php endif; ?>
<?php if($field->relationship_type == 'hasMany'): ?>

    public function <?php echo e(str_plural($field->field_name)); ?>()
    {
        return $this->hasMany('App\Objects\<?php echo e(makeObject($field->component->variable)); ?>', 'id_<?php echo $field->core_component->variable ?>');
    }
<?php endif; ?>
<?php if($field->relationship_type == 'belongsToMany'): ?>

    public function <?php echo e($comp = $field->component->variable); ?>()
    {
        return $this->belongsToMany('App\Objects\<?php echo e(makeObject($comp)); ?>', '<?php echo e($field->mediator_table); ?>', '<?php echo e($field->mediator_table_key); ?>', '<?php echo e($field->local_key); ?>');
    }
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
}
<?php /**PATH C:\wamp64\www\modilara\storage\components\templates/objecttemplate.blade.php ENDPATH**/ ?>