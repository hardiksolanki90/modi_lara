<div class="_mc">
  <?php if(model($field, 'field_text')): ?>
      <div class="_ref"><?php echo e(model($field, 'field_text')); ?></div>
  <?php else: ?>
  <div class="_ref" style="display:none;"></div>
  <?php endif; ?>
  <div class="_cfb">
    <a href="#" class="_close_field">Remove</a>
  </div>
  <div class="flex space-between full">
    <div class="_main">
      <?php echo $form->choice([
        'label' => 'Column Type',
        'name' => 'column_type[]',
        'value' => model($field, 'column_type'),
        'options' => $column_types
        ]); ?>

        <div class="rel_wrap">
          <div class="_replationship_type_wrapper none">
            <?php echo $form->choice([
              'label' => 'Relationship Type',
              'name' => 'relationship_type[]',
              'value' => model($field, 'relationship_type'),
              'options' => [
              'belongsTo' => 'Belongs To',
              'belongsToMany' => 'Belongs To Many',
              'hasMany' => 'hasMany',
              ],
              ]); ?>

            </div>
            <div class="_components_wrapper none">
              <?php echo $form->choice([
                'name' => 'relational_component_name[]',
                'label' => 'Relational Component Name',
                'value' => model($field, 'relational_component_name'),
                'options' => app()->context->component->orderBy('name', 'asc')->get()->toArray(),
                'value_key' => 'id',
                'text_key' => 'name',
                ]); ?>

              </div>
              <div class="local_key none">
                <?php echo $form->text([
                  'name' => 'local_key[]',
                  'label' => t('Local Key of current table'),
                  'value' => model($field, 'local_key')
                  ]); ?>

              </div>
              <div class="middle_table_wrapper none">
                <?php echo $form->choice([
                  'name' => 'mediator_table[]',
                  'label' => t('Mediator Table'),
                  'value' => model($field, 'mediator_table'),
                  'options' => $table_list,
                  'value_key' => 'value',
                  'text_key' => 'name',
                  ]); ?>

                </div>
                <div class="mediator_table_key_wrapper none">
                  <?php echo $form->text([
                    'name' => 'mediator_table_key[]',
                    'label' => t('Mediator Table Key'),
                    'value' => model($field, 'mediator_table_key')
                    ]); ?>

                  </div>
                  <div class="foreign-select-wrapper none">
                    <label for="foreign-select">Foreign Key</label>
                    <select class="foreign-select" id="foreign-select" name="foreign_key[]" >
                      <?php if(isset($field->foreign_key) && $field->foreign_key): ?>
                      <?php $cp = Schema::getColumnListing($component->table); ?>
                        <?php if(count($cp)): ?>
                          <?php $__currentLoopData = $cp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($c); ?>" <?php echo e(($c == $field->foreign_key ? 'selected' : '')); ?>><?php echo e($c); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                      <?php endif; ?>
                    </select>
                  </div>
                  </div>
                </div>
    <div class="_flex_column _center">
      <div class="_field_name">
        <?php echo $form->text([
          'name' => 'field[]',
          'label' => t('Field Name'),
          'value' => model($field, 'field_text'),
          'class' => 'field_name'
          ]); ?>

        </div>
        <div class="_input_type_wrapper">
          <?php echo $form->choice([
            'label' => 'Input Type',
            'name' => 'input_type[]',
            'class' => 'input_type',
            'value' => model($field, 'input_type', 'text'),
            'options' => [
            'text' => 'Text',
            'textarea' => 'Textarea',
            'number' => 'Number',
            'tel' => 'Phone',
            'select' => 'Select Dropdown',
            'radio' => 'Radio',
            'checkbox' => 'Checkbox',
            'file' => 'File',
            'media_image' => 'Media - Image',
            'media_video' => 'Media- Video',
            'media_pdf' => 'Media - PDF'
            ]
            ]); ?>

          </div>
          <div class="_input_defult none">
            <?php echo $form->text([
              'name' => 'default[]',
              'label' => t('Default'),
              'value' => model($field, 'default')
              ]); ?>

            </div>
            <?php echo $form->text([
              'name' => 'class[]',
              'label' => t('HTML Class'),
              'value' => model($field, 'class')
              ]); ?>

            </div>
    <div class="_flex_column">
      <?php echo $form->choice([
        'label' => 'Input Required',
        'name' => 'required_field[]',
        'value' => model($field, 'required', 1),
        'options' => ['No', 'Yes']
      ]); ?>

        <?php echo $form->choice([
          'label' => 'Use in Listing',
          'name' => 'use_in_listing[]',
          'wrapper_class' => 'form-group myForm-group is-focused',
          'class' => 'form-control',
          'value' => model($field, 'use_in_listing', 1),
          'options' => ['No', 'Yes']
          ]); ?>

          <?php echo $form->choice([
            'name' => 'fillable[]',
            'label' => 'Fillable',
            'value' => model($field, 'is_fillable', 1),
            'options' => ['No', 'Yes']
            ]); ?>

          </div>
  </div>
</div>
<?php /**PATH C:\wamp64\www\modilara\resources\views\admin\hardik-admin\templates/component/_partials/fields.blade.php ENDPATH**/ ?>