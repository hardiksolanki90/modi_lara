<?php $__env->startSection('content'); ?>
<div class="con">
  <div class="card">
    <div class="card-body">
      <?php echo $form->start('admin-user-create', 'component-add myForm'); ?>

        <div class="flex space-between">
          <?php echo $form->text([
            'name' => 'name',
            'label' => t('Component Name'),
            'required' => true,
            'value' => model($component, 'name'),
          ]); ?>


          <?php echo $form->text([
            'name' => 'table',
            'label' => t('Table'),
            'value' => model($component, 'table'),
            'required' => true,
          ]); ?>


          <?php echo $form->text([
            'name' => 'variable',
            'label' => t('Variable'),
            'value' => model($component, 'variable'),
            'required' => true,
          ]); ?>

          <?php echo $form->text([
            'name' => 'slug',
            'label' => t('Slug'),
            'value' => model($component, 'slug'),
            'required' => true,
            ]); ?>

        </div>

        <?php echo $form->choice([
          'label' => 'Controller',
          'name' => 'controller',
          'show_label_as_option' => false,
          'value' => model($component, 'controller'),
          'options' => ['none' => 'None', 'front' => 'Front', 'admin' => 'Admin', 'both' => 'Both']
        ]); ?>


          <hr>
          <h4>Fields</h4>
          <div class="_mc_wrapper">
            <?php if(c($component) && count($component->fields)): ?>
              <?php $fields = $component->fields()
              ->where('field_name', '!=', 'meta_title')
              ->where('field_name', '!=', 'meta_description')
              ->where('field_name', '!=', 'meta_keywords')
              ->get(); ?>

              <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('component._partials.fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
              <?php echo $__env->make('component._partials.fields', ['field' => ''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
            <div class="new-column"></div>
            <a href="#" class="_ac _afb"><i class="material-icons">add_circle_outline</i> Add fields</a>
          </div>
          <hr>
          <h4>Other Config</h4>
          <div class="flex space-between">
            <?php echo $form->choice([
                'name' => 'is_login_needed',
                'options' => ['No', 'Yes'],
                'value' => model($component, 'is_login_needed'),
                'label' => 'Is route need login?',
                'type' => 'radio',
                'reverse' => 'true',
                'wrapper_class' => 'switch'
            ]); ?>

            <?php echo $form->choice([
                'name' => 'is_meta_needed',
                'options' => ['No', 'Yes'],
                'value' => model($component, 'is_meta_needed'),
                'label' => 'Is Meta Fields Needed?',
                'type' => 'radio',
                'reverse' => 'true',
                'wrapper_class' => 'switch'
            ]); ?>

            <?php echo $form->choice([
                'name' => 'reset',
                'options' => ['No', 'Yes'],
                'value' => 0,
                'label' => 'Reset Component?',
                'type' => 'radio',
                'reverse' => 'true',
                'wrapper_class' => 'switch'
            ]); ?>

          </div>
          <hr>
          <div class="flex space-between">
            <?php echo $form->choice([
                'name' => 'is_admin_create',
                'options' => ['No', 'Yes'],
                'value' => model($component, 'is_admin_create'),
                'label' => 'Is Admin Create?',
                'type' => 'radio',
                'reverse' => 'true',
                'wrapper_class' => 'switch'
            ]); ?>

            <?php echo $form->choice([
                'name' => 'is_admin_list',
                'options' => ['No', 'Yes'],
                'value' => model($component, 'is_admin_list'),
                'label' => 'Is Admin List?',
                'type' => 'radio',
                'reverse' => 'true',
                'wrapper_class' => 'switch'
            ]); ?>

            <?php echo $form->choice([
                'name' => 'is_admin_delete',
                'options' => ['No', 'Yes'],
                'value' => model($component, 'is_admin_delete'),
                'label' => 'Is Admin Delete?',
                'type' => 'radio',
                'reverse' => 'true',
                'wrapper_class' => 'switch'
            ]); ?>

          </div>
          <hr>
          <div class="flex space-between">
            <?php echo $form->choice([
                'name' => 'is_front_create',
                'options' => ['No', 'Yes'],
                'value' => model($component, 'is_front_create'),
                'label' => 'Is Front Delete?',
                'wrapper_class' => 'switch',
                'type' => 'radio',
                'reverse' => true
            ]); ?>

            <?php echo $form->choice([
                'name' => 'is_front_list',
                'options' => ['No', 'Yes'],
                'value' => model($component, 'is_front_list'),
                'label' => 'Is Front List?',
                'wrapper_class' => 'switch',
                'type' => 'radio',
                'reverse' => true
            ]); ?>

            <?php echo $form->choice([
                'name' => 'is_front_view',
                'options' => ['No', 'Yes'],
                'value' => model($component, 'is_front_view'),
                'label' => 'Is Front View?',
                'wrapper_class' => 'switch',
                'type' => 'radio',
                'reverse' => true
            ]); ?>

          </div>
          <hr>
          <button type="submit" class="btn btn-primary btn-lg" name="button">Save Component</button>
        <?php echo $form->end(); ?>

      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\modilara\resources\views\admin\hardik-admin\templates/component/add.blade.php ENDPATH**/ ?>