<?php if(count($media)): ?>
  <div class="flex row-wrap row _media_libarary_wrapper">
    <?php $__currentLoopData = $media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $med): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="media-col">
        <div class="inner-div" id_media="<?php echo e($med->id); ?>">
          <?php if($med->type ==  'image'): ?>

            <img id_media="<?php echo e($med->id); ?>" class="select-library-img" type="image" src="<?php echo e(getMedia($med, '150, 150')); ?>" alt="">
            
          <?php elseif($med->type == 'application' && $med->format == 'pdf'): ?>
            <div class="select-library-img video-selector select-library-img" id_media="<?php echo e($med->id); ?>"></div>
            <a target="_blank" href="<?php echo e(getMedia($med)); ?>" id_media="<?php echo e($med->id); ?>">
              <i class="material-icons">picture_as_pdf</i>
              <?php echo e($med->name); ?>

            </a>

          <?php elseif($med->type == 'video'): ?>
            <?php if($med->format == 'embeded'): ?>
              <div class="select-library-img video-selector" id_media="<?php echo e($med->id); ?>"></div>
              <?php echo $med->name; ?>

            <?php else: ?>
              <div class="select-library-img video-selector" id_media="<?php echo e($med->id); ?>"></div>
              <video width="150" height="150" class="select-library-img" src="<?php echo e(getMedia($med)); ?>" id_media="<?php echo e($med->id); ?>"></video>
            <?php endif; ?>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <div class="links">
    <?php echo e($media->links()); ?>

  </div>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\modilara\resources\views\admin\hardik-admin\templates/media/_partials/list-only-media.blade.php ENDPATH**/ ?>