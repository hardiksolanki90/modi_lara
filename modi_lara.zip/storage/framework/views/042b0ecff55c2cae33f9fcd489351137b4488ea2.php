<?php $__currentLoopData = $obj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr class="m-datatable__row">
  <td><?php echo e($o->id); ?></td>
            <td>
        <span>
                      <?php echo e($o->name); ?>

                  </span>
      </td>
                <td>
        <span>
                      <?php echo e($o->email); ?>

                  </span>
      </td>
                <td>
        <span>
                      <?php echo e($o->mobile); ?>

                  </span>
      </td>
                <td>
        <span>
                      <?php echo e($o->password); ?>

                  </span>
      </td>
        <td>
    <div class="dropdown">
      <button class="btn btn-secondary btn-action dropdown-toggle" type="button" id="dropdownMenuButton_<?php echo e($o->id); ?>" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <?php echo e(t('Action')); ?>

      </button>
      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton_<?php echo e($o->id); ?>" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 37px, 0px); top: 0px; left: 0px; will-change: transform;">
        <a class="dropdown-item" href="<?php echo e(AdminURL('customer/edit/' . $o->id)); ?>"><?php echo e(t('Edit')); ?></a>
        <a class="dropdown-item" href="<?php echo e(AdminURL('customer/delete/' . $o->id)); ?>"><?php echo e(t('Delete')); ?></a>
        
      </div>
    </div>
  </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\wamp64\www\modilara\resources\views\admin\hardik-admin\templates/customer/_partials/list-only-customer.blade.php ENDPATH**/ ?>