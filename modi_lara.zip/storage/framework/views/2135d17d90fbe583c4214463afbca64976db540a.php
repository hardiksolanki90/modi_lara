namespace App\Http\Controllers\AdminControllers;

use App\Http\Controllers\AdminController;
use Input;
use Illuminate\Http\Request;

class <?php echo e($object); ?>Controller extends AdminController
{
    public function __construct()
    {
        parent::__construct();
        $this->component = app()->context->component
        ->where(['variable' => '<?php echo e($variable); ?>'])
        ->first();
    }

    public function initListing(Request $request)
    {
        $this->page['title'] = '<?php echo e(ucfirst($comp_obj->name)); ?>';
        if ($this->component->is_admin_create) {
          $this->page['action_links'][] = [
            'text' => t('Add ' . $this->component->name),
            'slug' => route($this->component->variable . '.add'),
            'icon' => '<i class="material-icons">add_circle_outline</i>'
          ];
        }

        $this->initProcessFilter();

        if ($this->filter) {
  <?php if (count($rels = $comp_obj->fields()->where('column_type', 'relationship')->get())) : ?>
          $<?php echo e($variable); ?> = app()->context-><?php echo e($variable); ?>

    <?php foreach ($rels as $rel) : ?>
      <?php if ($rel->relationship_type == 'belongsToMany') : ?>
          ->leftJoin('<?php echo $rel->mediator_table ?>', '<?php echo $rel->mediator_table ?>.<?php echo $rel->mediator_table_key ?>', '=', '<?php echo $rel->core_component->table ?>.id')
          ->leftJoin('<?php echo $rel->component->variable ?>', '<?php echo $rel->component->variable ?>.id', '=', '<?php echo $rel->mediator_table ?>.<?php echo $rel->local_key ?>')
      <?php endif; ?>
      <?php if ($rel->relationship_type == 'belongsTo') : ?>
          ->leftJoin('<?php echo $rel->component->table ?>', '<?php echo $rel->component->table ?>.<?php echo $rel->foreign_key ?>', '=', '<?php echo $rel->core_component->table ?>.<?php echo $rel->local_key ?>')
      <?php endif; ?>
      <?php if ($rel->relationship_type == 'hasMany') : ?>
          ->leftJoin('<?php echo $rel->component->table ?>', '<?php echo $rel->component->table ?>.id_<?php echo $rel->core_component->variable ?>', '=', '<?php echo $rel->core_component->table ?>.id')
      <?php endif; ?>
    <?php endforeach; ?>
          ->select('<?php echo $comp_obj->variable ?>.*')
          ->orderBy('id', 'desc')
          ->where($this->filter_search);
  <?php else : ?>
          $<?php echo e($variable); ?> = app()->context-><?php echo e($variable); ?>

          ->orderBy('id', 'desc')
          ->where($this->filter_search);
  <?php endif; ?>
        } else {
          $<?php echo e($variable); ?> = app()->context-><?php echo e($variable); ?>

          ->orderBy('id', 'desc');
        }

        $this->page['badge'] = count($<?php echo e($variable); ?>->get());
        $this->obj = $<?php echo e($variable); ?>->paginate(25);

        $listable = $this->component->fields
        ->where('use_in_listing', 1);

        $this->assign = [
          'listable' => $listable,
          'variable' => '<?php echo e($variable); ?>',
          'obj' => $this->obj,
        ];

        if ($request->ajax()) {
          $data = $this->assign;
          $html = view('<?php echo e($variable); ?>/_partials/list-only-<?php echo e($variable); ?>', $data);
          $html = prepareHTML($html);
          return json('success', $html, true, prepareHTML($<?php echo e($variable); ?>->paginate(25)->links()));
        }

        return $this->template('<?php echo e($variable); ?>.list');
    }

    public function initContentCreate($id = null)
    {
        if ($this->component->is_admin_list) {
          $this->page['action_links'][] = [
            'text' => t($this->component->name),
            'slug' => route($this->component->variable . '.list'),
            'icon' => '<i class="material-icons">reply</i>'
          ];
        }

        if ($this->component->is_admin_create && $id) {
          $this->page['action_links'][] = [
            'text' => t('Add'),
            'slug' => route($this->component->variable . '.add'),
            'icon' => '<i class="material-icons">add_circle_outline</i>'
          ];
        }

        $this->obj = app()->context-><?php echo e($variable); ?>;
        if ($id) {
          $this->obj = $this->obj->find($id);
        }

        if (!$id) {
          $this->page['title'] = 'Add <?php echo e(ucfirst($comp_obj->name)); ?>';
        } else {
          $this->page['title'] = '<?php echo e(ucfirst($comp_obj->name)); ?>: ' . $this->obj->name;
        }

        $fillable = $this->component->fields
        ->where('is_fillable', 1);

        $this->assign = [
          'fillable' => $fillable
        ];

        return $this->template('<?php echo e($variable); ?>.create');
    }

    public function initProcessCreate($id = null)
    {
        $data = $this->validateFields();
        $this->obj = app()->context-><?php echo e($variable); ?>;

        if ($id) {
          $this->obj = $this->obj->find($id);
        }

        $data = $this->obj;
  <?php $no_relationship = $comp_obj
  ->fields()
  ->where('column_type', '!=', 'relationship')
  ->where('column_type', '!=', 'file')
  ->where('is_fillable', 1)
  ->get(); ?>
    <?php if (count($no_relationship)) : ?>
      <?php foreach ($no_relationship as $field) : ?>
        $data-><?php echo e($field->field_name); ?> = Input::get('<?php echo e($field->field_name); ?>');
      <?php endforeach; ?>
    <?php endif; ?>
  <?php $file = $comp_obj->fields()
  ->where('column_type', 'file')
  ->where('is_fillable', 1)
  ->get(); ?>
  <?php if (count($file)) : ?>
    <?php foreach ($file as $field) : ?>
      $path = config('adlara.request')->file('file')->store('files');
      $data-><?php echo e($field->field_name); ?> = $path;
    <?php endforeach; ?>
  <?php endif; ?>

  <?php $relationships2 = $comp_obj->fields()
  ->where('column_type', 'relationship')
  ->where('relationship_type', '!=', 'belongsToMany')
  ->where('relationship_type', '!=', 'hasMany')
  ->where('is_fillable', 1)
  ->get(); ?>
    <?php if (count($relationships2)) : ?>
      <?php foreach ($relationships2 as $field) : ?>
        $data-><?php echo e($field->field_name); ?> = Input::get('<?php echo e($field->field_name); ?>');
      <?php endforeach; ?>
    <?php endif; ?>
        $data->save();


<?php $relationships = $comp_obj->fields()
->where('column_type', 'relationship')
->where('relationship_type', 'belongsToMany')
->where('is_fillable', 1)
->get(); ?>
  <?php if (count($relationships)) : ?>
    <?php foreach ($relationships as $field) : ?>
        if (count(Input::get('<?php echo e($field->field_name); ?>'))) {
          if ($id) {
            \App\Objects\<?php echo e(makeObject($field->mediator_table)); ?>::where('<?php echo e($field->mediator_table_key); ?>', $data->id)->forceDelete();
          }
          foreach (Input::get('<?php echo e($field->field_name); ?>') as $input) {
            $re = new \App\Objects\<?php echo e(makeObject($field->mediator_table)); ?>;
            $re-><?php echo e($field->local_key); ?> = $input;
            $re-><?php echo e($field->mediator_table_key); ?> = $data->id;
            $re->save();
          }
        }
    <?php endforeach; ?>
  <?php endif; ?>

<?php $relationships = $comp_obj->fields()
->where('column_type', 'relationship')
->where('relationship_type', 'hasMany')
->where('is_fillable', 1)
->get(); ?>
  <?php if (count($relationships)) : ?>
    <?php foreach ($relationships as $field) : ?>
        if (count($datas = explode(',', Input::get('<?php echo e($field->field_name); ?>')))) {
          if ($id) {
            \App\Objects\<?php echo e(makeObject($field->component->variable)); ?>::where('id_<?php echo $field->core_component->name ?>', $data->id)->forceDelete();
          }
          foreach ($datas as $input) {
            $re = new \App\Objects\<?php echo e(makeObject($field->component->variable)); ?>;
            $re-><?php echo e($field->field_name); ?> = $input;
            $re->id_<?php echo $field->core_component->name ?> = $data->id;
            $re->save();
          }
        }
    <?php endforeach; ?>
  <?php endif; ?>
        if (!$id) {
          return json('redirect', AdminURL($this->component->slug . '/edit/' . $data->id));
        }

        return json('success', t($this->component->name . ' updated'));
    }

    public function initProcessDelete($id = null)
    {
        $obj = app()->context-><?php echo $comp_obj->variable ?>->find($id);
        if ($obj) {
          $obj->delete();
          <?php $relationships = $comp_obj->fields()
          ->where('column_type', 'relationship')
          ->where('relationship_type', 'belongsToMany')
          ->where('is_fillable', 1)
          ->get(); ?>
          <?php if (count($relationships)) : ?>
            <?php foreach ($relationships as $field) : ?>
          \App\Objects\<?php echo makeObject($field->mediator_table) ?>::where('<?php echo $field->mediator_table_key ?>', $obj->id)->delete();
            <?php endforeach; ?>
          <?php endif; ?>
          $this->flash('success', '<?php echo ucwords($comp_obj->name) ?> with title <strong>' . $obj->name . '</strong> is deleted successufully');
        }
        return redirect(route('<?php echo $comp_obj->variable ?>.list'));
    }
}
<?php /**PATH C:\wamp64\www\modilara\storage\components\templates/admincontrollertemplate.blade.php ENDPATH**/ ?>