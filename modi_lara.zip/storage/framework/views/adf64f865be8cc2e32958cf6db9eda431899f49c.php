<?php $__env->startSection('content'); ?>
<div class="con">
  <div class="card">
    <div class="card-body">
          <?php echo $form->start('page-create-form', 'myForm'); ?>


        <?php echo $form->text([
          'name' => 'name',
          'required' => true,
          'label' => t('Name'),
          'value' => model($obj, 'name'),
          'class' => ''
          ]); ?>


        <?php echo $form->media([
          'label' => 'Featured Image',
          'name' => 'featured_image',
          'media' => model($obj, 'featured_image')
        ]); ?>


        <?php echo $form->media([
          'label' => 'Multiple Featured Image',
          'name' => 'featured_image',
          'media' => model($obj, 'featured_image'),
          'multiple' => true,
        ]); ?>


        <?php echo $form->media([
          'label' => 'Multiple Featured PDF',
          'name' => 'featured_image',
          'media' => model($obj, 'featured_pdf'),
          'multiple' => true,
          'object_type' => 'application'
        ]); ?>


          <?php echo $form->text([
            'name' => 'content',
            'required' => false,
            'label' => t('Content'),
            'value' => model($obj, 'content'),
            'class' => '',
            'class' => 'html-editor',
            'wrapper_class' => 'html-editor-wrap',
            'textarea' => true
            ]); ?>


        <?php echo $form->text([
          'name' => 'url',
          'required' => true,
          'label' => t('Url'),
          'value' => model($obj, 'url'),
          'class' => ''
          ]); ?>

          <?php echo $form->text([
            'name' => 'body_class',
            'required' => false,
            'label' => t('Body Class'),
            'value' => model($obj, 'body_class'),
            'class' => ''
            ]); ?>

          <?php echo $form->choice([
              'name' => 'status',
              'required' => false,
              'label' => t('Status'),
              'value' => model($obj, 'status'),
              'class' => '',
              'options' => ['No', 'Yes'],
              'reverse' => true
              ]); ?>

                                                  <hr>
              <?php echo $form->text([
                'name' => 'meta_title',
                'value' => model($obj, 'meta_title'),
                'label' => 'Meta Title',
                ]); ?>

                <?php echo $form->text([
                  'name' => 'meta_description',
                  'value' => model($obj, 'meta_description'),
                  'label' => 'Meta Description',
                  'textarea' => true,
                  ]); ?>

                  <?php echo $form->text([
                    'name' => 'meta_keywords',
                    'value' => model($obj, 'meta_keywords'),
                    'type' => 'text',
                    'label' => 'Meta Keywords',
                    ]); ?>

                                    <button type="submit" class="btn btn-primary btn-submit has-icon-right" name="button">
                    <i class="ion-ios-download-outline"></i>
                    <?php echo e(t('Save')); ?> page
                  </button>
                  <?php echo $form->end(); ?>

                    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\modilara\resources\views\admin\hardik-admin\templates/page/create.blade.php ENDPATH**/ ?>