<div class="select-media-wrapper">
  <?php $div_id = str_replace('[]', '', $data['id']); ?>
  <button <?php echo e($data['object_type'] ? 'object_type='.$data['object_type'].'' : ''); ?>  <?php echo e(($data['multiple'] ? 'multiple' : '')); ?> type="button" id="<?php echo e($div_id); ?>" class="btn btn-media select-media">
    <i class="material-icons">&#xE2C3;</i>
    <?php echo e($data['label']); ?>

  </button>


  <?php if($data['media']): ?>
    <?php echo generateMedia([
      'id' => $data['id'],
      'media' => $data['media']
    ]); ?>

  <?php endif; ?>
</div>
<?php /**PATH C:\wamp64\www\modilara\resources\views\admin\hardik-admin\templates/form/media.blade.php ENDPATH**/ ?>