<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,700|Material+Icons" rel="stylesheet">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e($page['title']); ?> • <?php echo e(config('app.name', 'Modilara')); ?></title>

    <link rel="canonical" href="<?php echo e(url()->current()); ?>">
    <!-- Styles -->
    <?php if(count($css_files)): ?>
      <?php $__currentLoopData = $css_files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $css): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <link type="text/css" href="<?php echo e($css); ?>" rel="stylesheet">
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <script type="text/javascript">
      CSRF = '<?php echo e(csrf_token()); ?>';
      CURRENT_URL = '<?php echo e(url()->current()); ?>';
      const ADMIN_URL = '<?php echo e(url(config('modilara.admin_route'))); ?>'
    </script>
</head>
<body class="sidebar-mini layout-fixed">
    <?php echo $__env->make('media._partials.upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('media._partials.library', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="app" class="wrapper">
        <!-- Navbar -->
        <nav class="main-header navbar navbar-expand navbar-white navbar-light">
          <!-- Left navbar links -->
          <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#"><i class="mdi mdi-reorder-horizontal left" style="font-size: 20px;"></i></a>
              </li>
              <li class="nav-item"><a class="nav-link" href="#"><?php echo e($page['title']); ?></a></li>
          </ul>


          <!-- Right navbar links -->
          <ul class="navbar-nav ml-auto _lll align-center">
              <?php if(count($page['action_links'])): ?>
                <?php $__currentLoopData = $page['action_links']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li>
                    <a href="<?php echo e($link['slug']); ?>" data-toggle="tooltip" title="<?php echo e($link['text']); ?>" class="<?php echo e((isset($link['class']) ? $link['class'] : '')); ?>">
                      <?php if($link['icon']): ?>
                        <?php echo $link['icon']; ?>

                      <?php endif; ?>
                      <?php echo e($link['text']); ?>

                    </a>
                  </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
              <li>
                <a class="_vl" href="<?php echo e(url('')); ?>" class="hidden-sm-and-down" target="_balnk">
                  Visit Site
                  <i class="mdi mdi-open-in-new"></i>
                </a>
              </li>
              <li class="nav-item dropdown">
                  <a class="nav-link" data-toggle="dropdown" href="#">
                    <?php echo e(app()->context->admin_user->getAdminUser()->name); ?>

                  </a>
                  <div class="dropdown-menu dropdown-menu dropdown-menu-right">
                      <a href="<?php echo e(route('employee.logout')); ?>" class="dropdown-item">
                        <i class="mdi mdi-power-standby mr-2"></i> Logout
                      </a>
                  </div>
              </li>
          </ul>
        </nav>
        <!-- /.navbar -->
        <?php echo $__env->make('_partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="content-wrapper">
            <section class="content pt-3">
                <div class="container-fluid">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </section>
        </div>
    </div>
    <!-- Scripts -->
    <?php if(count($js_files)): ?>
      <?php $__currentLoopData = $js_files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $js): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <script src="<?php echo e($js); ?>"></script>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <?php echo $__env->yieldContent('footer_script'); ?>
</body>
</html>
<?php /**PATH C:\wamp64\www\modilara\resources\views\admin\hardik-admin\templates/layouts/dashboard.blade.php ENDPATH**/ ?>