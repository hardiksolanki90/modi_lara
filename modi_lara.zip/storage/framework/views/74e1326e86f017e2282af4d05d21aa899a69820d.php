<?php $__env->startSection('content'); ?>
<div class="con">
  <div class="_tw card">
    <?php if(count($page['action_links'])): ?>
      <div class="_ph">
        <div class="_pas">
          <div class="action-bar-panel">
            <?php $__currentLoopData = $page['action_links']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <a data-toggle="tooltip" data-placement="top" data-original-title="<?php echo e($link['text']); ?>" class="rounded-s action-link <?php echo e((isset($link['class']) ? $link['class'] : '')); ?>" href="<?php echo e($link['slug']); ?>">
                <?php if($link['icon']): ?>
                  <?php echo $link['icon']; ?>

                <?php endif; ?>
                <span><?php echo e($link['text']); ?></span>
              </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
        <div class="_h">
          <?php echo e($page['title']); ?>

        </div>
      </div>
    <?php endif; ?>
    <div class="_tw_w card-body">
      <table class="table table-striped _ft" id="table_customer">
        <thead>
          <tr>
            <th filter="id">ID</th>
            <th filter="name">Name</th>
            <th filter="email">Email</th>
            <th filter="mobile">Mobile</th>
            <th filter="password">Password</th>
            <th><?php echo e(t('Actions')); ?></th>
          </tr>
          <tr class="filter"></tr>
        </thead>
        <tbody class="m-datatable__body">
          <?php echo $__env->make('customer/_partials/list-only-customer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </tbody>
      </table>
      <div class="links" table="table_customer">
        <?php echo e($obj->links()); ?>

      </div>
    
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\modilara\resources\views\admin\hardik-admin\templates/customer/list.blade.php ENDPATH**/ ?>