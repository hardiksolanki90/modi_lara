<?php if(!$data['material']): ?>
  <?php if($data['type'] != 'file'): ?>
  <div class="form-group myForm-group <?php echo e(($data['class'] == 'html-editor' ? 'html-editor-wrap' : '')); ?> <?php echo e(($data['wrapper_class'] ? $data['wrapper_class'] : '')); ?> <?php echo e((($data['textarea']) ? 'mytexta' : '')); ?> ">
    <?php if($data['label']): ?>
      <label for="<?php echo e($data['id']); ?>"><?php echo e($data['label']); ?><?php echo e(($data['required'] ? '*' : '')); ?></label>
    <?php endif; ?>
    <?php if(!$data['textarea']): ?>
      <input id="<?php echo e($data['id']); ?>" class="form-control my-input <?php echo e($data['class']); ?>" type="<?php echo e($data['type']); ?>" name="<?php echo e($data['name']); ?>" value="<?php echo e($data['value']); ?>" <?php echo e(($data['required'] ? 'required' : '')); ?>>
    <?php else: ?>

      <textarea id="<?php echo e($data['id']); ?>" class="form-control my-input <?php echo e($data['class']); ?>" type="<?php echo e($data['type']); ?>" name="<?php echo e($data['name']); ?>" rows="3" <?php echo e(($data['required'] ? 'required' : '')); ?>><?php echo e($data['value']); ?></textarea>
    <?php endif; ?>
  </div>
  <?php else: ?>
  <div class="custom-file">
    <input type="file" class="custom-file-input <?php echo e($data['class']); ?>" name="<?php echo e($data['name']); ?>" value="<?php echo e($data['value']); ?>" id="<?php echo e($data['id']); ?>">
    <label class="custom-file-label" for="<?php echo e($data['id']); ?>">Choose file</label>
  </div>
  <?php endif; ?>
<?php endif; ?>
<?php /**PATH C:\wamp64\www\modi_lara\resources\views\admin\hardik-admin\templates/form/text.blade.php ENDPATH**/ ?>