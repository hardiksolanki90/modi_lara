<aside class="main-sidebar sidebar-dark-primary elevation-4">
  <!-- Sidebar -->
  <div class="sidebar">

    <!-- Sidebar Menu -->
    <nav class="mt-2">
      <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        <!-- Add icons to the links using the .nav-icon class
             with font-awesome or any other icon font library -->
        <li class="nav-item has-treeview menu-open">
          <a href="<?php echo e(route('admin.dashboard')); ?>" class="nav-link">
            <i class="nav-icon mdi mdi-view-dashboard-outline"></i>
            <p>
              Dashboard
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
        </li>
        <?php if(count($sidebar_menu)): ?>
          <?php $__currentLoopData = $sidebar_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $head): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="nav-header"><?php echo e($head->name); ?></li>
            <?php if(count($head->menu)): ?>
              <?php $__currentLoopData = $head->menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item has-treeview">
                    <a href="<?php echo e(($m->slug ? route($m->slug) : '#')); ?>" class="nav-link flex align-center">
                        <?php if($m->icons): ?>
                            <i class="nav-icon mdi mdi-<?php echo e($m->icons); ?>"></i>
                        <?php else: ?>
                            <i class="nav-icon mdi mdi-cursor-default-click-outline"></i>
                        <?php endif; ?>
                    <p>
                        <?php echo e($m->name); ?>

                        <?php if(count($m->child) > 1): ?>
                            <i class="mdi mdi-chevron-right right"></i>
                        <?php endif; ?>
                    </p>
                    </a>
                    <?php if(count($m->child)): ?>
                        <ul class="nav nav-treeview">
                        <?php $__currentLoopData = $m->child; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route($child->slug)); ?>" class="nav-link flex align-center">
                                <i class="mdi mdi-arrow-right-bold-outline left"> </i>
                                <p><?php echo e($child->name); ?></p>
                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
      </ul>
    </nav>
    <!-- /.sidebar-menu -->
  </div>
  <!-- /.sidebar -->
</aside>
<?php /**PATH C:\wamp64\www\modi_lara\resources\views\admin\hardik-admin\templates/_partials/sidebar.blade.php ENDPATH**/ ?>