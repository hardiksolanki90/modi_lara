<?php $__env->startSection('content'); ?>
<div class="con">
  <div class="card">
    <?php if(count($page['action_links'])): ?>
      <div class="_ph">
        <div class="_pas">
          <div class="action-bar-panel">
            <?php $__currentLoopData = $page['action_links']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <a data-toggle="tooltip" data-placement="top" data-original-title="<?php echo e($link['text']); ?>" target="_blank" class="rounded-s action-link <?php echo e((isset($link['class']) ? $link['class'] : '')); ?>" href="<?php echo e($link['slug']); ?>">
                <?php if($link['icon']): ?>
                  <?php echo $link['icon']; ?>

                <?php endif; ?>
                <span><?php echo e($link['text']); ?></span>
              </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
        <div class="_h">
          <?php echo e($page['title']); ?>

        </div>
      </div>
    <?php endif; ?>
    <div class="card-body">
      <?php echo $form->start('configuration', 'myForm'); ?>

        <?php echo $form->text([
          'name' => 'ADMIN_EMAIL',
          'label' => t('ADMIN_EMAIL'),
          'required' => true,
          'value' => $ADMIN_EMAIL,
        ]); ?>

        <?php echo $form->text([
          'name' => 'SITE_URL',
          'label' => t('SITE_URL'),
          'required' => true,
          'value' => $SITE_URL,
        ]); ?>


        <div class="twof">
          <div class="_field">
            <?php echo $form->choice([
              'name' => 'SSL',
              'options' => ['No', 'Yes'],
              'value' => $SSL,
              'label' => 'SSL',
              'wrapper_class' => 'switch',
              'type' => 'radio',
              'reverse' => true,
              ]); ?>

          </div>
          <div class="_field">
            <?php echo $form->choice([
              'name' => 'CACHE',
              'options' => ['No', 'Yes'],
              'value' => $CACHE,
              'label' => 'CACHE',
              'wrapper_class' => 'switch',
              'type' => 'radio',
              'reverse' => true,
              ]); ?>

          </div>
        </div>
        <hr>
        <div class="twof">
          <div class="_field">
            <?php echo $form->choice([
                'name' => 'DEBUG_MODE',
                'options' => ['No', 'Yes'],
                'value' => $DEBUG_MODE,
                'label' => 'DEBUG MODE',
                'wrapper_class' => 'switch',
                'type' => 'radio',
                'reverse' => true
            ]); ?>

          </div>
        </div>
        <hr>
        <div class="twof">
          <div class="_field">
            <?php echo $form->choice([
              'name' => 'CSS_MINIFICATION',
              'options' => ['No', 'Yes'],
              'value' => $CSS_MINIFICATION,
              'label' => 'CSS MINIFICATION',
              'wrapper_class' => 'switch',
              'type' => 'radio',
              'reverse' => true
              ]); ?>

            </div>
            <div class="_field">
              <?php echo $form->choice([
                'name' => 'JS_MINIFICATION',
                'options' => ['No', 'Yes'],
                'value' => $JS_MINIFICATION,
                'label' => 'JS MINIFICATION',
                'wrapper_class' => 'switch',
                'type' => 'radio',
                'reverse' => true
                ]); ?>

            </div>
        </div>
        <hr>
        <button type="submit" name="button" class="btn btn-primary btn-submit has-icon-right"><i class="ion-ios-download-outline"></i>
          <?php echo e(t('Save Configuration')); ?>

        </button>
      <?php echo $form->end(); ?>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\modilara\resources\views\admin\hardik-admin\templates/configuration/create.blade.php ENDPATH**/ ?>