<?php $__env->startSection('content'); ?>
<div class="con">
  <div class="card _main_card">
    <?php if(count($page['action_links'])): ?>
      <div class="_ph">
        <div class="_pas">
          <div class="action-bar-panel">
            <?php $__currentLoopData = $page['action_links']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <a data-toggle="tooltip" data-placement="top" data-original-title="<?php echo e($link['text']); ?>" class="rounded-s action-link <?php echo e((isset($link['class']) ? $link['class'] : '')); ?>" href="<?php echo e($link['slug']); ?>">
                <?php if($link['icon']): ?>
                  <?php echo $link['icon']; ?>

                <?php endif; ?>
                <span><?php echo e($link['text']); ?></span>
              </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
        <div class="_h">
          <?php echo e($page['title']); ?>

        </div>
      </div>
    <?php endif; ?>
      <div class="card-body">
        <?php echo $form->start('employee-create-form', 'myForm tab-pad'); ?>

          <div class="tab-content">
            <div class="tab-pane container active" id="information">
              <?php echo $form->text([
                'name' => 'name',
                'required' => true,
                'label' => t('Name'),
                'value' => model($obj, 'name'),
                'class' => ''
                ]); ?>


              <?php echo $form->text([
                'name' => 'email',
                'required' => true,
                'type' => 'email',
                'label' => t('E-Mail Address'),
                'value' => model($obj, 'email'),
                'class' => ''
                ]); ?>


              <?php echo $form->text([
                'name' => 'password',
                'required' => false,
                'type' => 'password',
                'label' => t('Password'),
                'class' => ''
                ]); ?>


              <?php echo $form->text([
                'name' => 'password_confirmation',
                'required' => false,
                'type' => 'password',
                'label' => t('Confirm Password'),
                'class' => ''
                ]); ?>

                <div class="form-group myForm-group is-focused">
                  <label for="password_confirmation">User Access Permission</label>
                  <select multiple="multiple" class="form-control multi selectized" name="permission[]" id="permission">
                    <?php if(count($admin_menu)): ?>
                      <?php $__currentLoopData = $admin_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $am): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option <?php echo e((in_array($am->id, $selected_admin_menu) ? 'selected' : '')); ?> value="<?php echo e($am->id); ?>"><?php echo e($am->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                  </select>
                </div>
            </div>
          <div class="page_footer flex space-between">
            <div class="_ls">
            </div>
            <div class="_rs">
              <button type="submit" class="btn btn-primary btn-submit has-icon-right" name="button">
                <i class="ion-ios-download-outline"></i>
                <?php echo e(t('Save')); ?> Employee
              </button>
            </div>
          </div>
      <?php echo $form->end(); ?>

        </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\modilara\resources\views\admin\hardik-admin\templates/employee/register.blade.php ENDPATH**/ ?>