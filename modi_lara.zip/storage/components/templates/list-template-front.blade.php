@extends('layouts.app')
@section('content')
<div class="content">
  List for {{ $component->name }} is ready
</div>
@endsection
