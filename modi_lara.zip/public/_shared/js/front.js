var swiper = new Swiper('.slider-container', {
  pagination: {
    el: '.slider-pagination',
  },
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev',
  },
});
